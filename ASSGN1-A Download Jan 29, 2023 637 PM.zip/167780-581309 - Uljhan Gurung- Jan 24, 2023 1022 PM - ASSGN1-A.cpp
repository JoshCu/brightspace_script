/*

COPYRIGHT (C) 2022 Uljhan Gurung (ug9) All rights reserved.
CSI Assignment 1-A: Delete Repeat
Author. Uljhan Gurung
ug9@uakron.edu
Version. 1.01 01.23.2023
Purpose: 
The purpose of this assignment is to make sure that you know how to write a program that
uses unnamed namespace, separate compilation, external linkage, dynamic memory and
smart pointers.

*/

#include <iostream>
using namespace std;

void deleteRepeats(char originalArray[], int &SIZE);
void showResult(char originalArray[], int &SIZE);

int main()
{
    int SIZE = 10;
    char originalArray[SIZE];
        originalArray[0] = 'a';
        originalArray[1] = 'b';
        originalArray[2] = 'c';
        originalArray[3] = 'c';
        originalArray[4] = 'a';
        originalArray[5] = 'c';
        originalArray[6] = 'a';
        originalArray[7] = 'c';
        originalArray[8] = 'b';
        originalArray[9] = 'c';

    deleteRepeats(originalArray, SIZE);
    showResult(originalArray, SIZE);
    return 0;
}

void deleteRepeats(char originalArray[], int &SIZE)
{
    for(int i = 0; i < SIZE; i++)
    {
        for(int j = i + 1; j < SIZE; j++)
        {
            if( originalArray[i] == originalArray[j])
            {
                for(int k = j; k < SIZE-1; k++)
                {
                    originalArray[k] = originalArray[k+1];
                    
                }
                SIZE--;
            }
        }
    }
}

void showResult(char originalArray[], int &SIZE)
{
    for(int i = 0; i < SIZE; i++)
    {
        cout << originalArray[i] << endl;
    }
    return;
}