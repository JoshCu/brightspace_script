//
// Created by Dyson Carter on 1/10/23.
//

#ifndef ASSGN1_A_210_DELETEREPEATS_H
#define ASSGN1_A_210_DELETEREPEATS_H
#include "namespace.h"
bool foundIn(char, char[]); //prototype for a function I use in this function so the code is cleaner

//Pre-Condition:  pass function a char array the size of SIZE in the namespace
//Post-Condition: function returns a pointer to a new array without repeated chars
char* deleteRepeats(char arr[])
{
    char newArr[SIZE]; //this array is temporary for just getting no repeats
    int j = 0; //j is the amount of good elements in the new array
    for(int i = 0; i < SIZE; i++)
    {
        if (!foundIn(arr[i], newArr)) //function below (if the character is not found in the new array)
        {
            newArr[j] = arr[i]; //adds character to array
            j++; //amount of good elements increases
        }
    }

    char *finArr = new char[j]; //finArr is a pointer to the final array, size J
    for(int i = 0; i < j; i++)  //finArr becomes the same array as newArr but with dynamically allocated storage and no empty space
    {
        finArr[i] = newArr[i];
    }

    return finArr;
}

//Pre-Condition:  Pass function a char and a char array (array size == SIZE)
//Post-Condition: Function returns true if the char is in the array and false if not
bool foundIn(char c, char arr[])
{
    for(int i = 0; i < SIZE; i++){
        if(c == arr[i])
            return true;
    }

    return false;
}

#endif //ASSGN1_A_210_DELETEREPEATS_H
