#include <iostream>
#include "deleteRepeats.h"
#include "namespace.h"

int main()
{
    int count = SIZE; //for counting how many repeats
    char originalArray[SIZE];
    originalArray [0] = 'a';
    originalArray [1] = 'b';
    originalArray [2] = 'b';
    originalArray [3] = 'c';
    originalArray [4] = 'a';
    originalArray [5] = 'c';
    originalArray [6] = 'a';
    originalArray [7] = 'c';
    originalArray [8] = 'b';
    originalArray [9] = 'c';
    char* noRepeats = deleteRepeats(originalArray);

    for(int i = 0; i < SIZE; i++) //goes through new array for SIZE amount of times
    {
        if(isalnum(*(noRepeats + i))) { //if there is a good character to print
            std::cout << *(noRepeats + i); //print it
            count--; //and lower count since we know that version of the character wasn't repeated
        }
    }
    std::cout << std::endl << "There were " << count << " repeats.";

    return 0;
}
