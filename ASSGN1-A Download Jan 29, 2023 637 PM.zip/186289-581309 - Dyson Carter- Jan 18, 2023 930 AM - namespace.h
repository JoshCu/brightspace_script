//
// Created by Dyson Carter on 1/11/23.
//

#ifndef ASSGN1_A_210_NAMESPACE_H
#define ASSGN1_A_210_NAMESPACE_H
namespace {
    int const SIZE = 10;
}
#endif //ASSGN1_A_210_NAMESPACE_H
