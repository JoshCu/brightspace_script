// Author: Ben Engdahl (4750579)
// Assignment: ASSGN1-A
// Purpose: Delete repeated characters from a string

#include "deleteRepeats.hpp"

// Deletes repeated characters from an array, leaving only the first appearance 
// of any characters.
// Example: "abbcacacbc" => "abc"
// 
// PRECONDITIONS: `arr` must have less than `SIZE` non-null characters, and be NULL-terminated.
// POSTCONDITIONS: The resulting array is padded to length `SIZE` with NULL characters, so the 
// result "abc" is actually "abc\0\0\0\0\0\0\0\0".
std::array<char, SIZE> deleteRepeats(const char *arr) {
    auto out = std::array<char, SIZE>();
    int out_len=0;

    for (int i=0; i<SIZE-1; i++) {
        char c = arr[i];
        if (c=='\0') break; // Stop early at a NULL terminator

        // Check if this character is already a part of the output
        bool isRepeat=false;
        for (int j=0; j<out_len; j++) {
            if (out[j] == c) {
                isRepeat = true;
                break;
            }
        }
        // If this character isn't part of the output yet, add it to the end.
        if (!isRepeat) {
            out[out_len] = c;
            out_len++;
        }
    }
    // Pad the rest of the output with NULLs.
    for (; out_len<SIZE; out_len++) {
        out[out_len] = '\0';
    }
    return out;
}