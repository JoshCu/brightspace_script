// Author: Ben Engdahl (4750579)
// Assignment: ASSGN1-A
// Purpose: Delete repeated characters from a string

#pragma once

#include <memory>

const int SIZE = 11;

// Deletes repeated characters from an array, leaving only the first appearance 
// of any characters.
// Example: "abbcacacbc" => "abc"
// 
// PRECONDITIONS: `arr` must have less than `SIZE` non-null characters, and be NULL-terminated.
// POSTCONDITIONS: The resulting array is padded to length `SIZE` with NULL characters, so the 
// result "abc" is actually "abc\0\0\0\0\0\0\0\0".
std::array<char, SIZE> deleteRepeats(const char *arr);