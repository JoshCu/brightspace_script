// Author: Ben Engdahl (4750579)
// Assignment: ASSGN1-A
// Purpose: Delete repeated characters from a string

#include <memory>
#include <iostream>
#include "deleteRepeats.hpp"

int main() {
    // driver code as written in the assignment
    char originalArray[SIZE];
    originalArray [0] = 'a';
    originalArray [1] = 'b';
    originalArray [2] = 'b';
    originalArray [3] = 'c';
    originalArray [4] = 'a';
    originalArray [5] = 'c';
    originalArray [6] = 'a';
    originalArray [7] = 'c';
    originalArray [8] = 'b';
    originalArray [9] = 'c';
    originalArray [10] = '\0'; // make it a c-string for convenience
    std::array<char, SIZE> noRepeats = deleteRepeats(originalArray);
    
    std::cout << "Original: " << originalArray << '\n';
    std::cout << "New:      " << noRepeats.cbegin() << '\n';

    // noRepeats == "abc"
    if (noRepeats[0] == 'a' && noRepeats[1] == 'b' && noRepeats[2] == 'c' && noRepeats[3] == '\0') {
        std::cout << "PASSED\n";
    } else {
        std::cout << "FAILED\n";
    }

    int noRepeatsLen=0;
    while (noRepeats[noRepeatsLen]!='\0') noRepeatsLen++;

    std::cout << "Characters removed: " << (SIZE-1) - noRepeatsLen << '\n';

    return 0;
}