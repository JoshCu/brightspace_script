//I suspect this probably won't work properly
#include <iostream>

int * deleteRepeats(char checkedArray[]);

using namespace std;

const int SIZE = 10;

int main()
{
    int * noRepeats = nullptr;
    noRepeats = new int;

    char originalArray[SIZE];
    originalArray [0] = 'a';
    originalArray [1] = 'b';
    originalArray [2] = 'b';
    originalArray [3] = 'c';
    originalArray [4] = 'a';
    originalArray [5] = 'c';
    originalArray [6] = 'a';
    originalArray [7] = 'c';
    originalArray [8] = 'b';
    originalArray [9] = 'c';


    cout << "Original array: ";
    for(int i = 0; i < SIZE; ++i)
        cout << originalArray[i];
        cout << "\n";

    noRepeats = deleteRepeats(originalArray);

    cout << "\nCleaned array: ";
    for(int i = 0; i <= sizeof(noRepeats)+1; ++i)
        cout << *noRepeats[i];
        cout << "\n";



    return 0;
}




int * deleteRepeats(char checkedArray[]){
    int *temp = new int;

    for(int i = 0; i <= sizeof(checkedArray) ;++i){
        if(checkedArray[i] == checkedArray[i-1] || checkedArray[i] == checkedArray[i+1]){
            *(temp+i) = checkedArray[i];
        }
    }


    return temp;
}



