#ifndef CONSTANT_hpp
#define CONSTANT_hpp

//this header file is just for the forward declaration of the constant variable
namespace
{
    const int SIZE = 10;
} //unnamed namespace

#endif //CONSTANT_hpp
