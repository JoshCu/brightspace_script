#ifndef DELETEREPEATS_hpp
#define DELETEREPEATS_hpp

#include <memory>
#include <iostream>
#include "constant.h"


//the function will return a unique pointer with no repeated letters
std::unique_ptr<char[]> deleteRepeats(char arr[SIZE])  //function definition
{
	//make a copy unique pointer to store the non-repeats
	std::unique_ptr<char[]> copy(new char[SIZE]);
	int count = 0;
	for (int i = 0; i < SIZE; i++)
	{
		bool repeat = false;
		for (int j = 0; j < i; j++)
		{
			if (arr[i] == arr[j])
			{
				repeat = true;
				break;
			}
		}
		if (!repeat)
		{
			copy[count] = arr[i];
			count++;
		}
	}
	return copy;
}

#endif //DELETEREPEATS.hpp

