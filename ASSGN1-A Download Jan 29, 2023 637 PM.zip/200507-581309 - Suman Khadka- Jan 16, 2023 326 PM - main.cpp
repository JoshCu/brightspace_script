/*COPYRIGHT (C) 2023 Suman Khadka (4761417 ) All rights reserved.
Assignment 1A - Delete Repeats
Author. Suman Khadka
sk394@uakron.edu
VS Version. 17.4
Purpose: write a program that uses a function called deleteRepeats that
has an array of characters as a formal parameter, and that deletes all repeated letters from
the array
*/

#include <iostream>
#include <string>
#include <memory>
#include <cctype>
#include <cstring>
#include "deleteRepeats.h"
#include "constant.h"

using std::cout; using std::cin;
using std::unique_ptr; using std::string;
using std::endl;

unique_ptr<char[]> deleteRepeats(char arr[]);   //function declaration
//Precondition: An array of characters is passed as a formal parameter
//Postcondition: returns an unique pointer which contains only the non repeats

int main()
{
	//driver program
	char originalArray[SIZE]{};
	originalArray[0] = 'a';
	originalArray[1] = 'b';
	originalArray[2] = 'b';
	originalArray[3] = 'c';
	originalArray[4] = 'a';
	originalArray[5] = 'c';
	originalArray[6] = 'a';
	originalArray[7] = 'c';
	originalArray[8] = 'b';
	originalArray[9] = 'c';

	//smart pointer to store the non-repeats
	unique_ptr<char[]> noRepeats(new char[SIZE]);
	noRepeats = deleteRepeats(originalArray);

	//Original Array
	cout<<"Original Array: ";
	for (char letter : originalArray) //range based for loop to print the original array
	{
		cout << letter << " ";
	}

	cout <<"\n"<< endl;
    cout<<"After removing repeats:\n"<<endl;
	int newCount = 0, i=0;
	while (i < SIZE) {
		if (isalpha(noRepeats[i]))   //to check whether the non-repeated is a letter or not (we want to avoid blank spaces or anything other than letter from our dynamic array)
		{
			cout <<"OriginalArray["<<i<<"] = "<< noRepeats[i] <<endl;
			newCount++;
		}else{
		   break;   //end the loop (no further print)
		}
           i++;
	}
	cout << endl;
	//difference
	cout << "The total number  of repeats removed from the driver program is " << SIZE - newCount << endl;

	return 0;
}

