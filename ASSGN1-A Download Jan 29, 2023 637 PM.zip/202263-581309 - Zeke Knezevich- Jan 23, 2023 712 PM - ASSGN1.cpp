/*
COPYRIGHT (C) 2017 Zeke Knezevich (4767008) All rights reserved.
Assignment #1
Author. Zeke Knezevich
bek39@uakron.edu
Version. 1.01 07.09.2017
Purpose: Write a program that uses unnamed namespace, separate compilation, external linkage, dynamic memory, and smart pointers
*/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#define bool int
#define CHARS 256
#define SIZE 10


//PRE: Original Array is stored
//POST: Repeats located within array are deleted
char *deleteRepeats(char *array)
{
    bool hashArr[CHARS] = {0};
    int ipInd = 0, resInd = 0;
    char temp;

    while (*(array + ipInd))
    {
        temp = *(array + ipInd);
        if (hashArr[temp] == 0)
        {
            hashArr[temp] = 1;
            *(array + resInd) = *(array + ipInd);
            resInd++;
        }
        ipInd++;
    }
    *(array + resInd) = '\0';
    return array;
}


//PRE: Original Array is listed with values
//POST: Delete repeats function is called, displays new array
int main()
{
    char originalArray[SIZE];
    originalArray[0] = 'a';
    originalArray[1] = 'b';
    originalArray[2] = 'b';
    originalArray[3] = 'c';
    originalArray[4] = 'a';
    originalArray[5] = 'c';
    originalArray[6] = 'a';
    originalArray[7] = 'c';
    originalArray[8] = 'b';
    originalArray[9] = 'c';

    char *noRepeats;
    noRepeats = deleteRepeats(originalArray);
    printf("New Array: \n");

    for (int i = 0; i < strlen(noRepeats); i++)
        printf("%c \n", noRepeats[i]);
    printf("Number of characters deleted: ");
    printf("%d", SIZE - strlen(noRepeats) + 1);
    return 0;
}
