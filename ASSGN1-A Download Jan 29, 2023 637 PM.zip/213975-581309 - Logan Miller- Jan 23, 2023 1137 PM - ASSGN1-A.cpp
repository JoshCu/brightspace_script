//ASSGN1-A - Logan Miller

#include <iostream>
using namespace std;
const int SIZE = 10;

char* deleteRepeats(char arr[SIZE]) {
	int repeats = 0;

	for (int a = 0; a < SIZE; a++) {
		for (int b = a + 1; b < SIZE; b++) {
			if (arr[a] == arr[b]) {
				arr[b] = '-';
				repeats ++;
			}
		}
	}

	char *finalarr = new char[SIZE - repeats];
	int num = 0;
	for (int d = 0; d < SIZE; d++) {
		if (arr[d] != '-') {
			finalarr[num] = arr[d];
			num++;
		}
	}
	return finalarr;
}

int main() {
	char originalArray[SIZE];

	originalArray[0] = 'a';
	originalArray[1] = 'b';
	originalArray[2] = 'b';
	originalArray[3] = 'c';
	originalArray[4] = 'a';
	originalArray[5] = 'c';
	originalArray[6] = 'a';
	originalArray[7] = 'c';
	originalArray[8] = 'b';
	originalArray[9] = 'c';

	char *noRepeats = deleteRepeats(originalArray);

	int num = 0;
	for (int y = 0; y < SIZE; y++) {
		if (originalArray[y] == '-') {
			num++;
		}
	}

	for (int x = 0; x < SIZE - num; x++) {
		cout << "New Array with deletes:" << endl;
		cout << noRepeats[x] << endl;
		cout << "Number of repeats: " << num;
	}
}

