/*
 Riley Jarosz (4769075)
 CS2 ASSGN 01
 rmj60.ASSGN1.cpp
 */


#include <iostream>
#include <array>



namespace
{
const int SIZE = 10;
}

char* deleteRepeats(char charArr[]);
//Precondition: An array of character type must be inserted
//Postcondition: The function returns the pointer to the new character array, as well as prints out the new array.


int main()
{
    char* noRepeats;
    char originalArray[SIZE];
    originalArray[0] = 'a';
    originalArray[1] = 'b';
    originalArray[2] = 'b';
    originalArray[3] = 'c';
    originalArray[4] = 'a';
    originalArray[5] = 'c';
    originalArray[6] = 'a';
    originalArray[7] = 'c';
    originalArray[8] = 'b';                         
    noRepeats = deleteRepeats(originalArray);

    return 0;
}

char* deleteRepeats(char charArr[])
{
    int count = 0, j=0; //both used as counters, but count used as the number of elements in the new dynamic array
    char* newArr = new char();

    for (int i = 0; i < SIZE; i++)
    {
        for (j = 0; j < count; j++)
        {
        if (charArr[i] == newArr[j]) //if it is already in the dynamic array, it breaks to check the next number.
        break;
        }

        if (j == count) //this section allocates the new character to the new array
        {
            newArr[count] = charArr[i];
            count++;
        }
    }


    std::cout << "The new array: "; //prints out the array
    for (int k = 0; k < count; k++)
    {
        std::cout << " " << newArr[k];
    }
    std::cout << std::endl << "There were " << SIZE - count << " repeated letters removed from the array."; //finds the
    //deleted characters and prints this out as well.

    return newArr;
}