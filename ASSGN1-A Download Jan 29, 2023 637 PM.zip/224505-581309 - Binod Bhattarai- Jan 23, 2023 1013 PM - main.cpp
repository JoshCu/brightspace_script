//
//  main.cpp
//  ASSGN1A
//
//  Created by Binod Bhattarai on 1/22/23.
//

#include <iostream>
using namespace std;
const int SIZE = 10;
void getValues(char arr[], int &arraySize);
void deleteRepeats(char arr[], int &arraySize);
void showResult(char arr[], int arraySize);
int main()
{
    int arraySize;
        char arr[SIZE];
        getValues(arr, arraySize);
        deleteRepeats(arr, arraySize);
        showResult(arr, arraySize);
        return 0;
    
}
void getValues(char arr[], int &arraySize){
    cout << "How many values you want to insert: ";
    cin >> arraySize;
    for(int i = 0; i < arraySize; i++)
    {
        cout << "Enter a value: ";
        cin >> arr[i];
    }
    return;
}
void deleteRepeats(char arr[], int &arraySize)
{
    for(int i = 0; i<arraySize; i++)
    {
        for(int j = i+1; j < arraySize; j++){
            if(arr[i] == arr[j])
            {
                for(int m = j; m<arraySize-1; m++)
                {
                    arr[m] = arr[m+1];
                    
                }
                arraySize--;
            }
        }
    }
}
void showResult(char arr[], int arraySize)
{
    for(int i = 0; i<arraySize; i++){
        cout << arr[i] << endl;
    }
    return;
}


