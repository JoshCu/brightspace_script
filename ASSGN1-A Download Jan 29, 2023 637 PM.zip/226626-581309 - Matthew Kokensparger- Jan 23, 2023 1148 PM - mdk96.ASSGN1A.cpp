// Matthew Kokensparger
// Assignment 1A
// mdk96.ASSGN1A.cpp

#include <iostream>
#include <memory>

int ptrI = 0;

namespace
{
    const int SIZE = 10;

    class Entity
    {
    public:
        Entity()
        {}
        ~Entity()
        {}
    };
}

std::unique_ptr<Entity> deleteRepeats(char array[]);


int main()
{
    std::unique_ptr<Entity> noRepeats(new Entity());

    char originalArray[SIZE];
    originalArray[0] = 'a';
    originalArray[1] = 'b';
    originalArray[2] = 'b';
    originalArray[3] = 'c';
    originalArray[4] = 'a';
    originalArray[5] = 'c';
    originalArray[6] = 'a';
    originalArray[7] = 'c';
    originalArray[8] = 'b';
    originalArray[9] = 'c';
    noRepeats = deleteRepeats(originalArray);

    for (int count = 0; count < ptrI; count++)
    {
        std::cout << *noRepeats[count] << std::endl;
    }

    
}

std::unique_ptr<Entity> deleteRepeats(char array[])
{
    std::unique_ptr<Entity> ptr(char[]);
    bool add = false;

    for (int index = 0; index < SIZE; index++)
    {
        for (int ptrIndex = 0; ptrIndex < ptrI; ptrIndex++)
        {
            if (*ptr[ptrI] == array[index])
            {
                add = true;
            }
            else
            {
                add = false;
            }
        }
        if (add == true)
        {
            ptr[ptrI] = &array[index];
            ptrI++;
        }
    }
    return ptr;
}
