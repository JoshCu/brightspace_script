#include "functions.hpp"
#include <iostream>
#include<memory>
using namespace std;
namespace {
    const int SIZE = 10;
}
std::unique_ptr<char[]> deleteRepeats(char originalArray[]) {
    int count = 0;
    bool isRepeated;

    for (int i = 0; i < SIZE; i++) {
        isRepeated = false;
        for (int j = i + 1; j < SIZE; j++) {
            if (originalArray[i] == originalArray[j]) {
                isRepeated = true;
                break;
            }
        }
        if (!isRepeated) {
            count++;
        }
    }

    std::unique_ptr<char[]> newArray = std::make_unique<char[]>(count);
    int newArrayIndex = 0;

    for (int i = 0; i < SIZE; i++) {
        isRepeated = false;
        for (int j = i + 1; j < SIZE; j++) {
            if (originalArray[i] == originalArray[j]) {
                isRepeated = true;
                break;
            }
        }
        if (!isRepeated) {
            newArray[newArrayIndex] = originalArray[i];
            newArrayIndex++;
        }
    }


    return newArray;

}