#ifndef FUNCTIONS_HPP
#define FUNCTIONS_HPP
std::unique_ptr<char[]> deleteRepeats(char originalArray[]);


#endif
