#include "test.h"

unique_ptr<char[]> deleteRepeats(char arr[], int &counter)
{
    for(int i=0; i < SIZE; i++)                         // turns repeated characters to '0'
    {
        for(int j = i+1; j < SIZE; j++)
        {
            if(arr[i] == arr[j])
            {
                arr[j] = '0';
            }
        }
    }

    for(int i=0; i < SIZE; i++)                         // counts number of unique characters
    {
        if(arr[i] != '0')
        {
            counter++;
        }
    }

    unique_ptr<char[]> newArr(new char[counter]);

    int j = 0;
    for(int i = 0; i < SIZE; i++)
    {
        if(arr[i] != '0')
        {
            newArr[j++] = arr[i];
        }
    }

    return newArr;
}