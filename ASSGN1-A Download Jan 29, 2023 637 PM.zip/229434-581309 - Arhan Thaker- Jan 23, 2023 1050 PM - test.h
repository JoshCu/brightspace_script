#ifndef CS2_ASSGN1_TEST_H
#define CS2_ASSGN1_TEST_H
#include <iostream>

using std::unique_ptr;
using std::cout;
using std::endl;

//precondtion: pass function char[]
//             pass function int&
//postcondtion: deletes the repeated characters and returns an array of unique characters
unique_ptr<char[]> deleteRepeats(char[], int&);

namespace
{
    const int SIZE = 10;
}

#endif //CS2_ASSGN1_TEST_H

