#include <iostream>

using namespace std;

int main()
{
    cout << "Hello world from Nolan Mizen" << endl;
    return 0;
}
