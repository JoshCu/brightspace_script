#include <iostream>
#include <memory>
#include "functions.hpp"

namespace {
	const int SIZE = 10;
}


int main() {
    char originalArray[SIZE];
    originalArray[0] = 'a';
    originalArray[1] = 'b';
    originalArray[2] = 'b';
    originalArray[3] = 'c';
    originalArray[4] = 'a';
    originalArray[5] = 'c';
    originalArray[6] = 'a';
    originalArray[7] = 'c';
    originalArray[8] = 'b';
    originalArray[9] = 'c';
    std::unique_ptr<char[]> noRepeats = deleteRepeats(originalArray);

    std::cout << "New array: ";
    for (int i = 0; i < SIZE- sizeof(noRepeats) / sizeof(noRepeats[0])+1; i++) {
        std::cout << noRepeats.get()[i] << " ";
    }
    std::cout << std::endl;

    std::cout << "Number of repeats removed: " << sizeof(noRepeats) / sizeof(noRepeats[0])-1 << std::endl;

    return 0;
}