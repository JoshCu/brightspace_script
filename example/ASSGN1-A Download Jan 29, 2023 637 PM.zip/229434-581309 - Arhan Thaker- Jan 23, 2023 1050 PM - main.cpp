/*
Name: Arhan Thaker Pgm: ASSGN1-A
Purpose: This program delete the repeated characters from an array of characters and returns a
         array with the unique characters and also prints the number of repeated characters.
*/

#include "test.h"

int main()
{
    int count = 0;          // variable to hold number of unique characters

    char originalArray[SIZE];           // driver code
    originalArray [0] = 'a';
    originalArray [1] = 'b';
    originalArray [2] = 'b';
    originalArray [3] = 'c';
    originalArray [4] = 'a';
    originalArray [5] = 'c';
    originalArray [6] = 'a';
    originalArray [7] = 'c';
    originalArray [8] = 'b';
    originalArray [9] = 'c';
    unique_ptr<char[]> noRepeats = deleteRepeats(originalArray, count);         // calls function deleteRepeats

    cout << "New Array: ";                      // prints array of unique characters
    for(int i = 0; i < count; i++)
    {
        cout << noRepeats[i] << " ";
    }

    cout << endl << "Number of Repeated Characters: " << SIZE - count << endl;          // prints number of repeated characters

    return 0;
}
